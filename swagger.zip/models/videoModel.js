const db = require("../config/db");

const Video = {
  // Create a new video record
  create: async (videoData) => {
    // If the new record is active, update all currently active videos to inactive.
    if (videoData.status && videoData.status.toLowerCase() === "active") {
      const updateSql =
        "UPDATE videos SET status='inactive' WHERE status='active'";
      await db.query(updateSql);
    }
    // Insert the new video record
    const data = {
      title: videoData.title,
      subtitle: videoData.subtitle,
      video_url: videoData.video_url,
      status: videoData.status || "active",
    };
    const sql = "INSERT INTO videos SET ?";
    const [result] = await db.query(sql, data);
    return result;
  },

  // Retrieve all videos, ordered by created_at descending
  getAll: async () => {
    const sql = "SELECT * FROM videos ORDER BY created_at DESC";
    const [results] = await db.query(sql);
    return results;
  },

  // Retrieve a single video by id
  getById: async (id) => {
    const sql = "SELECT * FROM videos WHERE id = ?";
    const [results] = await db.query(sql, [id]);
    if (results.length === 0) return null;
    return results[0];
  },

  // Update a video record by id
  update: async (id, videoData) => {
    const data = {
      title: videoData.title,
      subtitle: videoData.subtitle,
      video_url: videoData.video_url,
      status: videoData.status,
    };

    // If the new status is active, force all other active videos to inactive.
    if (videoData.status && videoData.status.toLowerCase() === "active") {
      const updateOthersSql =
        "UPDATE videos SET status = 'inactive' WHERE id != ? AND status = 'active'";
      await db.query(updateOthersSql, [id]);
    }

    const sql = "UPDATE videos SET ? WHERE id = ?";
    const [result] = await db.query(sql, [data, id]);
    return result;
  },

  // Delete a video record by id
  delete: async (id) => {
    const sql = "DELETE FROM videos WHERE id = ?";
    const [result] = await db.query(sql, [id]);
    return result;
  },
};

module.exports = Video;
