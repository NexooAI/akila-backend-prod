const db = require("../config/db");

const Collection = {
  // Helper function to normalize paths
  normalizePath: (path) => {
    return path.replace(/\\/g, '/');
  },

  // Create a new collection
  create: async (data) => {
    try {
      const { name, thumbnail, status_images } = data;
      
      // Normalize paths before storing
      const normalizedThumbnail = Collection.normalizePath(thumbnail);
      const normalizedStatusImages = status_images.map(img => Collection.normalizePath(img));
      
      const [result] = await db.query(
        `INSERT INTO collections (name, thumbnail, status_images) 
         VALUES (?, ?, ?)`,
        [name, normalizedThumbnail, JSON.stringify(normalizedStatusImages)]
      );
      
      return { 
        success: true, 
        message: 'Collection created successfully',
        collectionId: result.insertId 
      };
    } catch (error) {
      console.error('Error in create collection:', error);
      throw error;
    }
  },

  // Get all collections
  getAll: async () => {
    try {
      const [collections] = await db.query(`
        SELECT id, name, thumbnail, 
               status_images,
               DATE_FORMAT(created_at, '%Y-%m-%d %H:%i:%s') as created_at,
               DATE_FORMAT(updated_at, '%Y-%m-%d %H:%i:%s') as updated_at
        FROM collections
        ORDER BY created_at DESC
      `);

      // Return collections with normalized paths
      console.log(JSON.stringify(collections),'-===-=-=======-=-=-=-==--==-=-=-');
      collections.forEach(collection => {
        console.log('collection for each',JSON.stringify(collection.status_images))
        
      })
      return collections.map(collection => ({
        
        ...collection,
        thumbnail: Collection.normalizePath(collection.thumbnail),
        status_images: collection.status_images ? 
          (collection.status_images).map(img => Collection.normalizePath(img)) : []
      }));
    } catch (error) {
      console.error('Error in get all collections:', error);
      throw error;
    }
  },

  // Get collection by ID
  getById: async (id) => {
    try {
      const [collections] = await db.query(`
        SELECT id, name, thumbnail, 
               status_images,
               DATE_FORMAT(created_at, '%Y-%m-%d %H:%i:%s') as created_at,
               DATE_FORMAT(updated_at, '%Y-%m-%d %H:%i:%s') as updated_at
        FROM collections
        WHERE id = ?
      `, [id]);

      if (collections.length === 0) {
        return null;
      }

      // Return collection with normalized paths
      const collection = collections[0];
      return {
        ...collection,
        thumbnail: Collection.normalizePath(collection.thumbnail),
        status_images: collection.status_images ? 
          JSON.parse(collection.status_images).map(img => Collection.normalizePath(img)) : []
      };
    } catch (error) {
      console.error('Error in get collection by id:', error);
      throw error;
    }
  },

  // Update collection
  update: async (id, data) => {
    try {
      const { name, thumbnail, status_images } = data;
      
      // Normalize paths before storing
      const normalizedThumbnail = Collection.normalizePath(thumbnail);
      const normalizedStatusImages = status_images.map(img => Collection.normalizePath(img));
      
      const [result] = await db.query(
        `UPDATE collections 
         SET name = ?, 
             thumbnail = ?, 
             status_images = ?,
             updated_at = CURRENT_TIMESTAMP
         WHERE id = ?`,
        [name, normalizedThumbnail, JSON.stringify(normalizedStatusImages), id]
      );

      if (result.affectedRows === 0) {
        return { success: false, message: 'Collection not found' };
      }

      return { 
        success: true, 
        message: 'Collection updated successfully',
        affectedRows: result.affectedRows
      };
    } catch (error) {
      console.error('Error in update collection:', error);
      throw error;
    }
  },

  // Delete collection
  delete: async (id) => {
    try {
      const [result] = await db.query(
        'DELETE FROM collections WHERE id = ?',
        [id]
      );

      if (result.affectedRows === 0) {
        return { success: false, message: 'Collection not found' };
      }

      return { 
        success: true, 
        message: 'Collection deleted successfully',
        affectedRows: result.affectedRows
      };
    } catch (error) {
      console.error('Error in delete collection:', error);
      throw error;
    }
  }
};

module.exports = Collection; 