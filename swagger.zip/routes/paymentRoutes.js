const express = require("express");
const router = express.Router();
const paymentController = require("../controllers/paymentController");
const { verifyToken, authorizeRole,verifyTokenaccess } = require("../middlewares/authenticate");

/**
 * @swagger
 * components:
 *   schemas:
 *     Payment:
 *       type: object
 *       properties:
 *         user_id:
 *           type: integer
 *           description: ID of the user who made the payment.
 *           example: 1
 *         investment_id:
 *           type: integer
 *           description: ID of the associated investment (if applicable).
 *           example: 10
 *         amount:
 *           type: number
 *           format: float
 *           description: Payment amount.
 *           example: 1500.50
 *         payment_date:
 *           type: string
 *           format: date-time
 *           description: Date and time when the payment was made.
 *         payment_method:
 *           type: string
 *           description: Payment method (e.g., Credit Card, UPI).
 *           example: "Credit Card"
 *         transaction_id:
 *           type: string
 *           description: Unique transaction reference.
 *           example: "XXXXRCYYYYMMDD########"
 *         payment_status:
 *           type: string
 *           description: Payment status (e.g., "Paid", "Pending", "Failed").
 *           example: "Paid"
 *       required:
 *         - user_id
 *         - amount
 *         - payment_method
 *         - payment_status
 *
 * securitySchemes:
 *   bearerAuth:
 *     type: http
 *     scheme: bearer
 *     bearerFormat: JWT
 *
 * tags:
 *   - name: Payments
 *     description: API for managing payment records
 */

/**
 * @swagger
 * /payment:
 *   post:
 *     summary: Create a new payment record
 *     tags: [Payments]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - investmentId
 *               - paymentAmount
 *               - userId
 *               - paymentMethod
 *               - schemeId
 *               - transactionId
 *             properties:
 *               investmentId:
 *                 type: integer
 *                 example: 26
 *               paymentAmount:
 *                 type: number
 *                 format: float
 *                 example: 20000.00
 *               userId:
 *                 type: integer
 *                 example: 1
 *               paymentMethod:
 *                 type: string
 *                 enum: ["UPI", "NetBanking", "CreditCard", "DebitCard"]
 *                 example: "UPI"
 *               schemeId:
 *                 type: integer
 *                 example: 4
 *               transactionId:
 *                 type: string
 *                 example: "XXXXRCYYYYMMDD########"
 *     responses:
 *       201:
 *         description: Payment created successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "Payment created successfully"
 *                 data:
 *                   type: object
 *                   properties:
 *                     investmentId:
 *                       type: integer
 *                       example: 26
 *                     paymentAmount:
 *                       type: number
 *                       format: float
 *                       example: 20000.00
 *                     userId:
 *                       type: integer
 *                       example: 1
 *                     paymentMethod:
 *                       type: string
 *                       example: "UPI"
 *                     schemeId:
 *                       type: integer
 *                       example: 4
 *                     transactionId:
 *                       type: string
 *                       example: "XXXXRCYYYYMMDD########"
 *       400:
 *         description: Bad request, invalid input.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   example: "Invalid input data"
 *       401:
 *         description: Unauthorized - Missing or invalid token.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   example: "Unauthorized"
 *       403:
 *         description: Forbidden - User not authorized.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   example: "Forbidden"
 *       500:
 *         description: Server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   example: "Internal server error"
 */

router.post("/payment", 
    //verifyToken, authorizeRole(["user"]), 
    paymentController.createPayment);


/**
 * @swagger
 * /payment:
 *   get:
 *     summary: Retrieve all payment records
 *     tags: [Payments]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: A list of payment records.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/Payment'
 *       401:
 *         description: Unauthorized - Missing or invalid token.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   example: "Unauthorized"
 *       500:
 *         description: Server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   example: "Internal server error"
 *
 * components:
 *   schemas:
 *     Payment:
 *       type: object
 *       properties:
 *         id:
 *           type: integer
 *           example: 1
 *         investmentId:
 *           type: integer
 *           example: 26
 *         paymentAmount:
 *           type: number
 *           format: float
 *           example: 20000.00
 *         userId:
 *           type: integer
 *           example: 1
 *         paymentMethod:
 *           type: string
 *           enum: ["UPI", "NetBanking", "CreditCard", "DebitCard"]
 *           example: "UPI"
 *         schemeId:
 *           type: integer
 *           example: 4
 *         transactionId:
 *           type: string
 *           example: "XXXXRCYYYYMMDD########"
 *         createdAt:
 *           type: string
 *           format: date-time
 *           example: "2025-03-16T14:30:00Z"
 */
router.get("/payment", 
    //verifyToken, authorizeRole(["user"]), 
    paymentController.getAllPayments);

/**
 * @swagger
 * /payment/{id}:
 *   get:
 *     summary: Retrieve a payment record by ID
 *     tags: [Payments]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: The payment record ID.
 *     responses:
 *       200:
 *         description: Payment record found.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Payment'
 *       401:
 *         description: Unauthorized - Missing or invalid token.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   example: "Unauthorized"
 *       404:
 *         description: Payment record not found.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   example: "Payment record not found"
 *       500:
 *         description: Server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   example: "Internal server error"
 */

router.get("/payment/:id", 
    //verifyToken, authorizeRole(["user"]), 
    paymentController.getPaymentById);

/**
 * @swagger
 * /payment/me:
 *   get:
 *     summary: Retrieve payment records for the authenticated user
 *     tags: [Payments]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: A list of payment records for the authenticated user.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/Payment'
 *       401:
 *         description: Unauthorized - Missing or invalid token.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   example: "Unauthorized"
 *       500:
 *         description: Server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   example: "Internal server error"
 */

router.get("/payment/user", 
    //verifyToken, authorizeRole(["user"]), 
    paymentController.getPaymentsByUser);

/**
 * @swagger
 * /payment/{id}:
 *   put:
 *     summary: Update a payment record by ID
 *     tags: [Payments]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: header
 *         name: Authorization
 *         required: true
 *         schema:
 *           type: string
 *         description: "Bearer token for authentication. Example: 'Bearer <your_token>'"
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: The payment record ID.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               paymentAmount:
 *                 type: number
 *                 format: float
 *                 example: 25000.00
 *               paymentMethod:
 *                 type: string
 *                 enum: ["UPI", "NetBanking", "CreditCard", "DebitCard"]
 *                 example: "NetBanking"
 *               transactionId:
 *                 type: string
 *                 example: "XXXXRCYYYYMMDD########"
 *     responses:
 *       200:
 *         description: Payment updated successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "Payment updated successfully"
 *       400:
 *         description: Bad request - Invalid input.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   example: "Invalid request body"
 *       401:
 *         description: Unauthorized - Missing or invalid token.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   example: "Unauthorized"
 *       404:
 *         description: Payment record not found.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   example: "Payment record not found"
 *       500:
 *         description: Server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   example: "Internal server error"
 */

router.put("/payment/:id", 
   // verifyToken, authorizeRole(["user"]),
     paymentController.updatePayment);


/**
 * @swagger
 * /payment/{id}:
 *   delete:
 *     summary: Delete a payment record by ID
 *     tags: [Payments]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: header
 *         name: Authorization
 *         required: true
 *         schema:
 *           type: string
 *         description: "Bearer token for authentication. Example: 'Bearer <your_token>'"
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: The payment record ID.
 *     responses:
 *       200:
 *         description: Payment deleted successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "Payment deleted successfully"
 *       401:
 *         description: Unauthorized - Missing or invalid token.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   example: "Unauthorized"
 *       404:
 *         description: Payment record not found.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   example: "Payment record not found"
 *       500:
 *         description: Server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   example: "Internal server error"
 */

router.delete("/payment/:id",
    //verifyToken,authorizeRole(['user']),
     paymentController.deletePayment);
router.post('/initiate',verifyToken,authorizeRole(['user']), paymentController.initiatePayment);
router.post('/status', paymentController.handleJuspayResponse);

module.exports = router;
