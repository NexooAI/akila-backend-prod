// routes/schemeRoutes.js
const express = require("express");
const router = express.Router();
const schemeController = require("../controllers/schemeController");
const upload = require("../upload");
const { verifyToken, authorizeRole } = require("../middlewares/authenticate");
/**
 * @swagger
 * components:
 *   schemas:
 *     Scheme:
 *       type: object
 *       properties:
 *         SCHEMEID:
 *           type: number
 *           description: Auto-generated scheme ID.
 *         SCHEMENAME:
 *           type: string
 *         SCHEMETYPE:
 *           type: string
 *         SCHEMENO:
 *           type: string
 *         REGNO:
 *           type: string
 *         ACTIVE:
 *           type: string
 *         BRANCHID:
 *           type: string
 *         INS_TYPE:
 *           type: string
 *         DESCRIPTION:
 *           type: string
 *         SLOGAN:
 *           type: string
 *         IMAGE:
 *           type: string
 *           description: File path of the uploaded image.
 *         ICON:
 *           type: string
 *           description: File path of the uploaded icon.
 *         created_at:
 *           type: string
 *           format: date-time
 *       required:
 *         - SCHEMENAME
 *         - SCHEMETYPE
 *         - SCHEMENO
 *         - REGNO
 *         - ACTIVE
 *         - BRANCHID
 *         - INS_TYPE
 *
 * tags:
 *   - name: Schemes
 *     description: API for managing schemes
 */

/**
 * @swagger
 * /schemes:
 *   post:
 *     summary: Create a new scheme
 *     description: API endpoint to create a new scheme record with file uploads for image and icon.
 *     tags:
 *       - Schemes
 *     consumes:
 *       - multipart/form-data
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required:
 *               - SCHEMENAME
 *               - SCHEMETYPE
 *               - SCHEMENO
 *               - REGNO
 *               - BRANCHID
 *               - INS_TYPE
 *               - duration_months
 *               - scheme_plan_type_id
 *               - payment_frequency_id
 *             properties:
 *               SCHEMENAME:
 *                 type: string
 *                 example: "Gold Investment Plan"
 *               SCHEMETYPE:
 *                 type: string
 *                 enum: [FIXED, FLEXI, Weight]
 *               SCHEMENO:
 *                 type: string
 *                 example: "12345"
 *               REGNO:
 *                 type: string
 *                 example: "REG-98765"
 *               ACTIVE:
 *                 type: string
 *                 enum: [Y, N]
 *                 example: "Y"
 *               BRANCHID:
 *                 type: integer
 *                 example: 2
 *               INS_TYPE:
 *                 type: string
 *                 example: "Gold-based"
 *               DESCRIPTION:
 *                 type: string
 *                 example: "Best gold savings plan"
 *               SLOGAN:
 *                 type: string
 *                 example: "Invest today, secure tomorrow"
 *               type:
 *                 type: string
 *                 enum: [gold, silver]
 *                 example: "gold"
 *               fixed:
 *                 type: number
 *                 format: float
 *                 example: 0.0
 *               duration_months:
 *                 type: integer
 *                 example: 11
 *               scheme_plan_type_id:
 *                 type: integer
 *                 example: 2
 *               payment_frequency_id:
 *                 type: array
 *                 items:
 *                   type: integer
 *                 example: [4]
 *               IMAGE:
 *                 type: string
 *                 format: binary
 *               ICON:
 *                 type: string
 *                 format: binary
 *     responses:
 *       201:
 *         description: Scheme created successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "Scheme created successfully"
 *                 data:
 *                   $ref: '#/components/schemas/Scheme'
 *       400:
 *         description: Bad request due to missing required fields or invalid data
 *       500:
 *         description: Server error
 */
router.post(
  "/schemes",
  // verifyToken,authorizeRole(["Super Admin"]),
  upload.fields([
    { name: "IMAGE", maxCount: 1 },
    { name: "ICON", maxCount: 1 },
  ]),
  schemeController.createScheme
);

/**
 * @swagger
 * /schemes:
 *   get:
 *     summary: Retrieve all schemes
 *     description: Retrieve a list of all schemes along with their associated chits and branch details.
 *     tags: [Schemes]
 *     responses:
 *       200:
 *         description: A list of schemes.
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Scheme'
 *       500:
 *         description: Server error.
 */
 router.get("/schemes",
//verifyToken,authorizeRole(["Admin", "Super Admin","user"]),
 schemeController.getAllSchemes);

/**
 * @swagger
 * /schemes/{id}:
 *   get:
 *     summary: Retrieve a scheme by ID
 *     description: Retrieve a single scheme by its SCHEMEID, including associated chits and branch details.
 *     tags: [Schemes]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: number
 *         description: Scheme ID.
 *     responses:
 *       200:
 *         description: A scheme object.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Scheme'
 *       404:
 *         description: Scheme not found.
 *       500:
 *         description: Server error.
 */
router.get("/schemes/:id",
 // verifyToken,authorizeRole(["Admin", "Super Admin","Branch Manager","Sales Executive","user"]),
   schemeController.getSchemeById);
/**
 * @swagger
 * /schemes/{id}:
 *   put:
 *     summary: Update an existing scheme record with optional file uploads.
 *     description: Updates scheme details while preserving existing chit records. Allows new chits to be added without modifying old ones.
 *     tags:
 *       - Schemes
 *     consumes:
 *       - multipart/form-data
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         schema:
 *           type: integer
 *         description: Unique ID of the scheme to update.
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required:
 *               - SCHEMENAME
 *               - SCHEMETYPE
 *               - duration_months
 *               - scheme_plan_type_id
 *               - payment_frequency_id
 *             properties:
 *               SCHEMENAME:
 *                 type: string
 *                 example: "Gold Investment Plan"
 *               SCHEMETYPE:
 *                 type: string
 *                 enum: [FIXED, FLEXI, Weight]
 *                 example: "FIXED"
 *               SCHEMENO:
 *                 type: string
 *                 example: "12345"
 *               REGNO:
 *                 type: string
 *                 example: "REG-98765"
 *               ACTIVE:
 *                 type: string
 *                 enum: [Y, N]
 *                 example: "Y"
 *               BRANCHID:
 *                 type: integer
 *                 example: 2
 *               INS_TYPE:
 *                 type: string
 *                 example: "Gold-based"
 *               DESCRIPTION:
 *                 type: string
 *                 example: "Best gold savings plan"
 *               SLOGAN:
 *                 type: string
 *                 example: "Invest today, secure tomorrow"
 *               type:
 *                 type: string
 *                 enum: [gold, silver]
 *                 example: "gold"
 *               fixed:
 *                 type: number
 *                 format: float
 *                 example: 0.0
 *               duration_months:
 *                 type: integer
 *                 example: 11
 *               scheme_plan_type_id:
 *                 type: integer
 *                 example: 2
 *               payment_frequency_id:
 *                 type: array
 *                 items:
 *                   type: integer
 *                 example: [4]
 *               IMAGE:
 *                 type: string
 *                 format: binary
 *                 description: Optional image file for the scheme.
 *               ICON:
 *                 type: string
 *                 format: binary
 *                 description: Optional icon file for the scheme.
 *     responses:
 *       200:
 *         description: Scheme updated successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "Scheme updated successfully"
 *                 data:
 *                   type: object
 *                   example:
 *                     SCHEMENAME: "Gold Savings Plan"
 *                     SCHEMETYPE: "FIXED"
 *                     duration_months: 12
 *                     scheme_plan_type_id: 3
 *                     payment_frequency_id: [4]
 *                     IMAGE: "/uploads/scheme_image.jpg"
 *       400:
 *         description: Validation error due to missing fields.
 *       500:
 *         description: Server error while updating scheme.
 */

router.put(
  "/schemes/:id",
  //verifyToken,authorizeRole(["Super Admin"]),
  upload.fields([
    { name: "IMAGE", maxCount: 1 },
    { name: "ICON", maxCount: 1 },
  ]),
  schemeController.updateScheme
);
/**
 * @swagger
 * /schemes/{id}:
 *   delete:
 *     summary: Delete a scheme
 *     description: Delete a scheme record by its SCHEMEID.
 *     tags: [Schemes]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: number
 *         description: Scheme ID.
 *     responses:
 *       200:
 *         description: Scheme deleted successfully.
 *       500:
 *         description: Server error.
 */
router.delete("/schemes/:id",
  //verifyToken,authorizeRole(["Super Admin"]), 
  schemeController.deleteScheme);

module.exports = router;