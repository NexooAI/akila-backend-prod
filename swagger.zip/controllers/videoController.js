const Video = require("../models/videoModel");

exports.createVideo = async (req, res) => {
  try {
    // Pass req.body instead of req
    const result = await Video.create(req.body);
    res.json({
      message: "Video created successfully",
      data: result,
      status: 200,
    });
  } catch (err) {
    console.error("Error creating video:", err);
    res.status(500).json({ error: err.sqlMessage || err });
  }
};

exports.getAllVideos = async (req, res) => {
  try {
    const videos = await Video.getAll();
    res.json({ data: videos, status: 200 });
  } catch (err) {
    res.status(500).json({ error: err.sqlMessage || err });
  }
};

exports.getVideoById = async (req, res) => {
  const id = req.params.id;
  try {
    const video = await Video.getById(id);
    if (!video) {
      return res.status(404).json({ message: "Video not found", status: 404 });
    }
    res.json({ data: video, status: 200 });
  } catch (err) {
    res.status(500).json({ error: err.sqlMessage || err });
  }
};

exports.updateVideo = async (req, res) => {
  const id = req.params.id;
  try {
    const result = await Video.update(id, req.body);
    res.json({
      message: "Video updated successfully",
      data: result,
      status: 200,
    });
  } catch (err) {
    res.status(500).json({ error: err.sqlMessage || err });
  }
};

exports.deleteVideo = async (req, res) => {
  const id = req.params.id;
  try {
    const result = await Video.delete(id);
    res.json({
      message: "Video deleted successfully",
      data: result,
      status: 200,
    });
  } catch (err) {
    res.status(500).json({ error: err.sqlMessage || err });
  }
};
