module.exports = {
  secret: "nexooAi",
};
