const express = require("express");
const router = express.Router();
const paymentController = require("../controllers/paymentController");
const { verifyToken, authorizeRole, verifyTokenaccess } = require("../middlewares/authenticate");

/**
 * @swagger
 * components:
 *   schemas:
 *     Payment:
 *       type: object
 *       properties:
 *         id:
 *           type: integer
 *           example: 1
 *         investmentId:
 *           type: integer
 *           example: 26
 *         paymentAmount:
 *           type: number
 *           format: float
 *           example: 20000.00
 *         userId:
 *           type: integer
 *           example: 1
 *         paymentMethod:
 *           type: string
 *           enum: ["UPI", "NetBanking", "CreditCard", "DebitCard"]
 *           example: "UPI"
 *         schemeId:
 *           type: integer
 *           example: 4
 *         transactionId:
 *           type: string
 *           example: "XXXXRCYYYYMMDD########"
 *         createdAt:
 *           type: string
 *           format: date-time
 *           example: "2025-03-16T14:30:00Z"
 *   securitySchemes:
 *     bearerAuth:
 *       type: http
 *       scheme: bearer
 *       bearerFormat: JWT
 * 
 * tags:
 *   - name: Payments
 *     description: API for managing payment records
 */

/**
 * @swagger
 * /payments/initiate:
 *   post:
 *     summary: Initiate a new payment
 *     tags: [Payments]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - investmentId
 *               - amount
 *               - paymentMethod
 *             properties:
 *               investmentId:
 *                 type: integer
 *                 example: 26
 *               amount:
 *                 type: number
 *                 format: float
 *                 example: 20000.00
 *               paymentMethod:
 *                 type: string
 *                 enum: ["UPI", "NetBanking", "CreditCard", "DebitCard"]
 *                 example: "UPI"
 *     responses:
 *       200:
 *         description: Payment initiated successfully
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Server error
 */
router.post('/initiate', 
// verifyToken, authorizeRole(['user']),
 paymentController.initiatePayment);

/**
 * @swagger
 * /payments/status:
 *   post:
 *     summary: Handle payment gateway response
 *     tags: [Payments]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               status:
 *                 type: string
 *                 example: "SUCCESS"
 *               transactionId:
 *                 type: string
 *                 example: "XXXXRCYYYYMMDD########"
 *     responses:
 *       200:
 *         description: Payment status updated successfully
 *       500:
 *         description: Server error
 */
router.post('/status', paymentController.handleJuspayResponse);

/**
 * @swagger
 * /payments/user:
 *   get:
 *     summary: Get payments for authenticated user
 *     tags: [Payments]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: List of user payments
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Payment'
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Server error
 */
router.get('/user', 
// verifyToken,
 paymentController.getPaymentsByUser);

/**
 * @swagger
 * /payments:
 *   post:
 *     summary: Create a new payment record
 *     tags: [Payments]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Payment'
 *     responses:
 *       201:
 *         description: Payment created successfully
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Server error
 *   get:
 *     summary: Get all payments
 *     tags: [Payments]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: List of all payments
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Payment'
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Server error
 */
router.post('/', 
// verifyToken, 
paymentController.createPayment);
router.get('/', 
// verifyToken,
 paymentController.getAllPayments);

/**
 * @swagger
 * /payments/{id}:
 *   get:
 *     summary: Get payment by ID
 *     tags: [Payments]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Payment ID
 *     responses:
 *       200:
 *         description: Payment details
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Payment'
 *       401:
 *         description: Unauthorized
 *       404:
 *         description: Payment not found
 *       500:
 *         description: Server error
 *   put:
 *     summary: Update payment by ID
 *     tags: [Payments]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Payment ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Payment'
 *     responses:
 *       200:
 *         description: Payment updated successfully
 *       401:
 *         description: Unauthorized
 *       404:
 *         description: Payment not found
 *       500:
 *         description: Server error
 *   delete:
 *     summary: Delete payment by ID
 *     tags: [Payments]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Payment ID
 *     responses:
 *       200:
 *         description: Payment deleted successfully
 *       401:
 *         description: Unauthorized
 *       404:
 *         description: Payment not found
 *       500:
 *         description: Server error
 */
router.get('/:id',
//  verifyToken,
 paymentController.getPaymentById);
router.put('/:id', 
// verifyToken,
 paymentController.updatePayment);
router.delete('/:id',
//  verifyToken,
 paymentController.deletePayment);

module.exports = router;
