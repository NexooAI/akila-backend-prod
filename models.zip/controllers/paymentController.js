const Payment = require("../models/paymentModel");
const {
  createPaymentSession,
  checkPaymentStatus,
  handlePayResponse,
} = require("../utils/juspayService");
const fs = require("fs");
const crypto = require("crypto");
const path = require("path");

// Load Public and Private Keys
const PRIVATE_KEY_PATH = path.join(__dirname, "privateKey.pem");
const PUBLIC_KEY_PATH = path.join(__dirname, "key_2bd2dcf3a2ec497384e8d4724e2f33be.pem");

const privateKey = fs.readFileSync(process.env.PRIVATE_KEY_PATH, "utf8");
const publicKey = fs.readFileSync(process.env.PUBLIC_KEY_PATH, "utf8");
const SIGNING_METHOD = "RSA"; // Change to "HMAC" if needed
const SECRET_KEY = "your-secure-hmac-secret-key"; // Use only for HMAC
// Your HDFC SmartWay Response Key (Get this from HDFC Dashboard)
const RESPONSE_KEY =process.env.RESPONSE_KEY; // Securely store this key

// WebSocket server instance
const { eventEmitter } = require("../index");
/**
 * Function to verify Juspay response signature using HMAC-SHA256
 */
function verifyJuspaySignature(responseData, receivedSignature) {
  // Remove 'signature' from responseData to compute the signature correctly
  console.log("RESPONSE_KEY",RESPONSE_KEY)
  const dataToSign = { ...responseData };
  delete dataToSign.signature;

  // Sort the keys in ascending order
  const sortedKeys = Object.keys(dataToSign).sort();

  // Create a concatenated string of values in sorted order
  const dataString = sortedKeys.map((key) => dataToSign[key]).join("|");

  // Generate HMAC-SHA256 signature using the Response Key
  const hmac = crypto.createHmac("sha256", RESPONSE_KEY);
  hmac.update(dataString);
  const expectedSignature = hmac.digest("base64"); // Juspay provides Base64-encoded signatures
console.log('expacted',expectedSignature,receivedSignature)
  return expectedSignature === receivedSignature; // Return true if valid, false otherwise
}
function verify_hmac(params, secret) {
console.log("parms",params)
  var paramsList = [];
  for (var key in params) {
    if (key != 'signature' && key != 'signature_algorithm') {
      paramsList[key] = params[key];
    }
  }

  paramsList = sortObjectByKeys(paramsList);

  var paramsString = '';
  for (var key in paramsList) {
    paramsString = paramsString + key + '=' + paramsList[key] + '&';
  }

  let encodedParams = encodeURIComponent(paramsString.substring(0, paramsString.length - 1));
  let computedHmac = crypto.createHmac('sha256', secret).update(encodedParams).digest('base64');
  let receivedHmac = decodeURIComponent(params.signature);

  console.log("computedHmac :", computedHmac)
  console.log("receivedHmac :", receivedHmac)
  const buffer1 = Buffer.from(decodeURIComponent(computedHmac), 'base64');
  const buffer2 = Buffer.from(receivedHmac, 'base64');
  return crypto.timingSafeEqual(buffer1, buffer2);
 // return decodeURIComponent(computedHmac) == receivedHmac;
}



function sortObjectByKeys(o) {
  return Object.keys(o)
    .sort()
    .reduce((r, k) => ((r[k] = o[k]), r), {});
}

//console.log(verify_hmac({"status_id":"21","status":"CHARGED","order_id":"**6**3**","signature":"******crdU/AW8BkpqnMHK2********TE=","signature_algorithm":"HMAC-SHA256"},{{Response Key}}))
exports.createPayment = async (req, res) => {
  try {
    //req.body.userId=req.user.id
    const result = await Payment.create(req.body);
    if(result.success)
    {
      res.status(201).json({
        message: "Payment created successfully",
        data: result,
        status: 200,
      });
    }
    else
    {
      res.status(500).json({
        message: "Error in payment processing",
        data: result,
       
      });
    }
    
  } catch (err) {
    console.error("Error creating payment:", err);
    res.status(500).json({ error: err.sqlMessage || err });
  }
};
/**
 * Generate a secure digital signature using RSA or HMAC
 */
function signRequest(data) {
  // Add security measures: Timestamp & Nonce to prevent replay attacks
  data.timestamp = Date.now();
  data.nonce = crypto.randomBytes(16).toString("hex");

  // Canonical JSON sorting to ensure consistent signing
  const jsonString = JSON.stringify(data, Object.keys(data).sort());

  if (SIGNING_METHOD === "RSA") {
    const sign = crypto.createSign("SHA256");
    sign.update(jsonString);
    sign.end();
    return sign.sign(privateKey, "base64");
  } else if (SIGNING_METHOD === "HMAC") {
    return crypto.createHmac("sha256", SECRET_KEY).update(jsonString).digest("hex");
  }
  throw new Error("Invalid signing method");
}
/**
 * Initiate Payment
 */
exports.initiatePayment = async (req, res) => {
  try {
    console.log('responsekey',RESPONSE_KEY)
    const userId = req.body.userId||req.user.id;
    console.log("userId",userId)
    const investmentId = req.body.investmentId;
    const schemeId = req.body.schemeId;
    const userName = req.body.userName;
    const userEmail = req.body.userEmail;
    const userMobile = req.body.userMobile;
    console.log("userids", userId);
    const orderId = `order_${userId.toString()}_${investmentId}_${Date.now()}`;
    console.log('orderId',orderId)
    const amount = req.body.amount;
    // const returnUrl = `${req.protocol}://${req.get("host")}/payments/status`;
    const returnUrl = `${req.protocol}s://${req.get("host")}/payments/status`;
   
    const requestData = {
      orderId,
      amount: req.body.amount,
      returnUrl: `${req.protocol}s://${req.get("host")}/payments/status`,
      userId: userId.toString(),
      investmentId: req.body.investmentId,
      schemeId: req.body.schemeId,
      userName: req.body.userName,
      userEmail: req.body.userEmail,
      userMobile: req.body.userMobile,
    };

    // Generate digital signature
    const signature = signRequest(requestData);

    // Define signature algorithm
    const signatureAlgo = {
      signature_algorithm: SIGNING_METHOD === "RSA" ? "RSA-SHA256" : "HMAC-SHA256",
    };
    // Create a payment session with Juspay
    const session = await createPaymentSession(
      orderId,
      amount,
      returnUrl,
      userId.toString(),
      investmentId,
      schemeId,
      userName,
      userEmail,
      userMobile,
      signature
    );

    // Store payment details in the database
    await Payment.create({ orderId, amount, status: "PENDING" });

    res.json({ success: true, session });
  } catch (error) {
    res.status(500).json({ success: false, error });
  }
};


// Function to Sign Response for Frontend
const signResponse = (data) => {
  const signer = crypto.createSign("RSA-SHA256");
  signer.update(JSON.stringify(data));
  return signer.sign(privateKey, "base64");
};

/**
 * Handle Payment Response
 */
exports.handlePaymentStatus = async (req, res) => {
  try {
    console.log("request", req.body);
    const orderId = req.body.order_id || req.body.orderId;
    if (!orderId)
      return res
        .status(400)
        .json({ success: false, error: "order_id is required" });

    // Fetch payment status from Juspay
    const statusResponse = await checkPaymentStatus(orderId);
    const status = statusResponse.status;

    // Show success or failure view
    if (status === "CHARGED") {
      return res.render("paymentSuccess", { orderId });
    } else {
      return res.render("paymentFailure", { orderId });
    }
  } catch (error) {
    res.status(500).json({ success: false, error });
  }
};





exports.handleJuspayResponse = async (req, res) => {
  const { order_id,signature } = req.body; // Getting the orderId from the request body
  const orderIdValue = order_id;
  const requestBodyString = JSON.stringify(req.body); // Convert request body to string
  // Validate orderId
 
  if (!orderIdValue) {
    return res.status(400).json(makeError("order_id is required"));
  }
 
  try {
    if (!verify_hmac(req.body, RESPONSE_KEY)) {
      return res.status(400).json({ success: false, message: "Invalid response signature. Possible response tampering detected!" });
    }
    // Call the service to check the payment status
    const { statusResponse, message } = await handlePayResponse(orderIdValue);

    // Log the status response for debugging (or use a structured logger in production)
    console.log("Juspay Status Response:", statusResponse);
   // If status is PENDING, wait and recheck
   if (["PENDING", "PENDING_VBV"].includes(statusResponse.status)) {
    console.log("Waiting for final verification...");
    await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait 5 sec

    // **Second Inquiry: Final Verification**
    statusResponse = await handlePayResponse(orderIdValue);
    console.log("Second Inquiry Response:", statusResponse);
  }
    let customMessage = "";
    let customStatus = "";

    // Customize the response based on the payment status
    switch (statusResponse.status) {
      case "CHARGED":
        customMessage = "Payment completed successfully.";
        customStatus = "success";
        break;
      case "PENDING":
      case "PENDING_VBV":
        customMessage = "Payment is pending. Please wait for confirmation.";
        customStatus = "pending";
        break;
      case "AUTHORIZATION_FAILED":
        customMessage =
          "Payment authorization failed. Please check your payment details.";
        customStatus = "failure";
        break;
      case "AUTHENTICATION_FAILED":
        customMessage =
          "Payment authentication failed. Please check your credentials.";
        customStatus = "failure";
        break;
      default:
        customMessage = `Payment status is ${statusResponse.status}. Please contact support for assistance.`;
        customStatus = "failure";
        break;
    }

    // Emit payment status update event to frontend via WebSocket
    eventEmitter.emit("payment_status_update", {
      orderId: orderIdValue,
      status: customStatus,
      message: customMessage,
      paymentResponse: statusResponse,
    });
    // res.render('loading', { orderId: order_id }); // Show loading page first
    // Return the formatted response from Juspay with the customized message
 
   // res.redirect(`/loading?orderId=${order_id}`);
   return res.json(makeJuspayResponse({
    success: customStatus === 'success',
    message: customMessage,
    statusResponse, // Send the actual status response from Juspay for transparency
  }));
  } catch (error) {
    // Log the error for debugging (could also use a structured logger)
    console.error("Error processing Juspay response:", error);

    // Return error response with a generic message
    return res
      .status(500)
      .json(makeError("An error occurred while processing the payment status"));
  }
};

exports.getAllPayments = async (req, res) => {
  try {
    const payments = await Payment.getAll();
    res.status(200).json({ data: payments, status: 200 });
  } catch (err) {
    res.status(500).json({ error: err.sqlMessage || err });
  }
};

exports.getPaymentById = async (req, res) => {
  try {
    const id = req.params.id;
    const payment = await Payment.getById(id);
    if (!payment) {
      return res
        .status(404)
        .json({ message: "Payment not found", status: 404 });
    }
    res.status(200).json({ data: payment, status: 200 });
  } catch (err) {
    res.status(500).json({ error: err.sqlMessage || err });
  }
};

exports.getPaymentsByUser = async (req, res) => {
  try {
    const userId = req.params.user_id||req.user.id;
    const payments = await Payment.getByUserId(userId);
    res.status(200).json({ data: payments, status: 200 });
  } catch (err) {
    res.status(500).json({ error: err.sqlMessage || err });
  }
};

exports.updatePayment = async (req, res) => {
  try {
    const id = req.params.id;
    const result = await Payment.update(id, req.body);
    res.status(200).json({
      message: "Payment updated successfully",
      data: result,
      status: 200,
    });
  } catch (err) {
    res.status(500).json({ error: err.sqlMessage || err });
  }
};

exports.deletePayment = async (req, res) => {
  try {
    const id = req.params.id;
    const result = await Payment.delete(id);
    res.status(200).json({
      message: "Payment deleted successfully",
      data: result,
      status: 200,
    });
  } catch (err) {
    res.status(500).json({ error: err.sqlMessage || err });
  }
};
const makeError = (message = "Something went wrong") => {
  return {
    success: false,
    message: message,
  };
};

// Helper to format Juspay API responses
function makeJuspayResponse(successRspFromJuspay) {
  if (successRspFromJuspay == undefined) return successRspFromJuspay;
  if (successRspFromJuspay.http != undefined) delete successRspFromJuspay.http;

  return successRspFromJuspay;
}
