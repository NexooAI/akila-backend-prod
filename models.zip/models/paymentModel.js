const db = require("../config/db");
const logger=require('../middlewares/logger')
const { v4: uuidv4 } = require('uuid');
const Payment = {
 
  create: async (data) => {
    const connection = await db.getConnection();
  
    try {
      await connection.beginTransaction();
      let { investmentId, paymentAmount, userId, paymentMethod, schemeId, transactionId, orderId,chitId,isManual,utr_reference_number } = data;
      console.log("data",transactionId)
       const manualPayment = isManual || 'no'; 

      if (paymentAmount <= 0) {
        return { success: false, message: "Invalid payment amount." };
      }
      if (manualPayment === 'no' && (!transactionId || !orderId)) {
        return { success: false, message: "Transaction ID and Order ID are required for online payments." };
      }
      let utr_reference=null
      if(manualPayment=='no')
      {

      
      // Step 1: Check for duplicate transaction
      const [existingTransaction] = await connection.execute(
        `SELECT id FROM payments WHERE transaction_id = ? LIMIT 1`,
        [transactionId]
      );
      console.log("existing",JSON.stringify(existingTransaction))
    
      if (existingTransaction.length > 0)  {
        await connection.rollback();
        return { success: false, message: "Duplicate transaction detected." };
      }
  
      // Step 2: Check for duplicate order
      const [existingOrder] = await connection.execute(
        `SELECT id FROM payments WHERE order_id = ?`,
        [orderId]
      );
      
      if (existingOrder.length > 0) {
        await connection.rollback();
        return { success: false, message: "Duplicate order detected." };
      }
    }
      // Step 3: Fetch scheme details
      const [schemeResult] = await connection.execute(
        `SELECT s.type, s.scheme_plan_type_id, c.payment_frequency as payment_frequency_id FROM chits as c join schemes as s on c.SchemeId=s.id WHERE c.id = ? LIMIT 1`,
        [chitId]
      );
  
      if (schemeResult.length === 0) {
        await connection.rollback();
        return { error: true, message: "Scheme not found." };
      }

      //step4:Get the fixed amount the chits table
       // Step 3: Fetch scheme details
       const [chitResult] = await connection.execute(
        `SELECT AMOUNT as  fixed  FROM chits WHERE SchemeId  = ? LIMIT 1`,
        [schemeId]
      );
      if (chitResult.length === 0) {
        await connection.rollback();
        return { error: true, message: "chit not found." };
      }
        console.log('chitResult',JSON.stringify(chitResult))
        const [investmentData] = await connection.execute(
        `SELECT firstMonthAmount FROM investments WHERE id = ? LIMIT 1`,
        [investmentId]
      );

      let firstMonthAmount = investmentData.length > 0 ? investmentData[0].firstMonthAmount : 0;

      console.log("First Month Amount from Investment:", firstMonthAmount);

      const { type: schemeType, scheme_plan_type_id, payment_frequency_id } = schemeResult[0];
      const { fixed: fixed } = chitResult[0];
  
      // Step 4: Fetch scheme plan type and payment frequency names
      const [[planTypeResult]] = await connection.execute(
        `SELECT name FROM scheme_plan_types WHERE id = ?`,
        [scheme_plan_type_id]
      );
  
      const [[frequencyResult]] = await connection.execute(
        `SELECT name FROM payment_frequencies WHERE id = ?`,
        [payment_frequency_id]
      );
  
      const planTypeName = planTypeResult ? planTypeResult.name : null;
      const frequencyName = frequencyResult ? frequencyResult.name : null;
  console.log("scheme",planTypeName,frequencyName,paymentAmount,fixed)
      // Step 5: If scheme is "fixed", validate payment amount
      if (planTypeName && planTypeName.toLowerCase() === "fixed") {
        if (parseFloat(paymentAmount) !== parseFloat(firstMonthAmount)) {
          await connection.rollback();
          return { error: true, message: `Payment amount should be exactly ₹${firstMonthAmount} for fixed schemes.` };
        }
      }
  
      // Step 6: Fetch active gold & silver rates
      const [rateResult] = await connection.execute(
        `SELECT gold_rate, silver_rate FROM rates WHERE status = 'active'`
      );
      if (rateResult.length === 0) {
        await connection.rollback();
        return { error: true, message: "Active rates not found." };
      }
      const { gold_rate, silver_rate } = rateResult[0];
  
      let goldWeightGained = 0;
      let silverWeightGained = 0;
      let finalGoldRate = 0;
      let finalSilverRate = 0;
  
      if (schemeType === "gold") {
        goldWeightGained = parseFloat(paymentAmount) / parseFloat(gold_rate);
        finalGoldRate = gold_rate;
      } else if (schemeType === "silver") {
        silverWeightGained = parseFloat(paymentAmount) / parseFloat(silver_rate);
        finalSilverRate = silver_rate;
      }
  
      const utcPaymentDate = new Date().toISOString().slice(0, 19).replace("T", " "); // UTC format
  
      // Step 7: Fetch last installment month
      const [lastPaymentResult] = await connection.execute(
        `SELECT MAX(monthNumber) AS lastPaidMonth FROM payments WHERE investment_id = ? AND payment_status = 'success'`,
        [investmentId]
      );
  
      let installmentMonth = 1;
      if (lastPaymentResult.length > 0 && lastPaymentResult[0].lastPaidMonth !== null) {
        installmentMonth = lastPaymentResult[0].lastPaidMonth + 1;
      }
    if (isManual === 'yes') {
        const manualPayment = generateManualPaymentIds(userId, investmentId);
      
        orderId = manualPayment.orderId;
      
        if (paymentMethod === 'Cash') {
          transactionId = manualPayment.transactionId;
        }
      }
      if ( isManual=='yes' &&
        ['UPI', 'NetBanking', 'CreditCard', 'DebitCard'].includes(paymentMethod) &&
        utr_reference_number) {
          const [existingManualUPI] = await connection.execute(
            `SELECT id FROM payments WHERE utr_reference = ? LIMIT 1`,
            [utr_reference_number]
          );
          console.log("Exisitng",existingManualUPI)
          if (existingManualUPI.length > 0) {
            await connection.rollback();
            return { success: false, message: "Duplicate UTR reference for manual payment." };
          }
          utr_reference=utr_reference_number||null
      }
      // Step 8: Insert payment record
      const [paymentData] = await connection.execute(
        `INSERT INTO payments (investment_id, user_id, amount, current_goldrate, current_silverrate, gold_rate, silver_rate, payment_date, payment_status, transaction_id, payment_method, monthNumber, created_at, updated_at, order_id,isManual,utr_reference) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?)`,
        [
          investmentId,
          userId,
          paymentAmount,
          finalGoldRate,
          finalSilverRate,
          goldWeightGained.toFixed(2),
          silverWeightGained.toFixed(2),
          utcPaymentDate,
          "success",
          transactionId,
          paymentMethod,
          installmentMonth,
          utcPaymentDate,
          utcPaymentDate,
          orderId,
          manualPayment,
          utr_reference
        ]
      );
  
      const insertedId = paymentData.insertId;
  console.log("insert",insertedId)
      await connection.commit();
      return {
        success: true,
        message: "Payment added successfully.",
        paymentId: insertedId,
        installmentMonth,
        goldWeightGained,
        silverWeightGained,
        schemeType,
        planTypeName,
        frequencyName
      };
  
    } catch (error) {
      logger.error(error)
      await connection.rollback();
      console.error("Error adding payment:", error);
      return { error: true, message: "Database error occurred." };
    } finally {
      connection.release();
    }
  },
  
  
  

  // Retrieve all payment records ordered by creation date (descending)
  getAll: async () => {
    const sql = "SELECT * FROM payments ORDER BY created_at DESC";
    const [results] = await db.query(sql);
    return results;
  },

  // Retrieve a single payment record by id
  getById: async (id) => {
    const sql = "SELECT * FROM payments WHERE id = ?";
    const [results] = await db.query(sql, [id]);
    if (results.length === 0) return null;
    return results[0];
  },

  // Retrieve payments for a specific user
  getByUserId: async (userId) => {
    const sql =
      "SELECT * FROM payments WHERE user_id = ? ORDER BY payment_date DESC";
    const [results] = await db.query(sql, [userId]);
    return results;
  },

  // Update a payment record by id
  update: async (id, paymentData) => {
    const data = {
      user_id: paymentData.user_id,
      investment_id: paymentData.investment_id || null,
      amount: paymentData.amount,
      payment_date: paymentData.payment_date,
      payment_method: paymentData.payment_method,
      transaction_id: paymentData.transaction_id || null,
      payment_status: paymentData.payment_status,
    };

    const sql = "UPDATE payments SET ? WHERE id = ?";
    const [result] = await db.query(sql, [data, id]);
    return result;
  },

  // Delete a payment record by id
  delete: async (id) => {
    const sql = "DELETE FROM payments WHERE id = ?";
    const [result] = await db.query(sql, [id]);
    return result;
  },

  getRecentPaymentsByUser: async (userId, limit = 5) => {
    const connection = await db.getConnection();
    try {
      const [rows] = await connection.query(
        `SELECT 
          id,
          amount,
          payment_status as status,
          created_at,
          transaction_id
        FROM payments 
        WHERE user_id = ? 
        ORDER BY created_at DESC 
        LIMIT ?`,
        [userId, limit]
      );
      return rows;
    } catch (error) {
      logger.error('Error getting recent payments:', error);
      throw error;
    } finally {
      connection.release();
    }
  }
};
function generateManualPaymentIds(userId,investment_id) {
  const timestamp = Date.now(); // current UTC time in milliseconds
  const randomUuid = uuidv4().split('-')[0]; // short unique string
  const prefix = 'DC_MANUAL';

  const transactionId = `${prefix}_TXN_${userId}_${investment_id}_${timestamp}_${randomUuid}`;
  const orderId = `${prefix}_ORD_${userId}_${investment_id}_${timestamp}`;

  return { transactionId, orderId };
}

module.exports = Payment;
